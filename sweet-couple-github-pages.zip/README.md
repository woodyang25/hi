# Our Sweet Little World ♡ — GitHub Pages

## Publish it for free

1. Sign in to https://github.com/
2. Click **+** → **New repository**.
3. Name it `sweet-couple-site`.
4. Choose **Public** (required for GitHub Free Pages), then create the repository.
5. In the repository, choose **Add file** → **Upload files**.
6. Upload `index.html` and `.nojekyll` from this folder. You can also upload this README.
7. Click **Commit changes**.
8. Open **Settings** → **Pages**.
9. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
10. Choose branch **main**, folder **/(root)**, then click **Save**.
11. Wait a few minutes. The Pages page will show the published address, usually:
    `https://YOUR-GITHUB-USERNAME.github.io/sweet-couple-site/`

## Notes

- This is a static HTML/CSS/JavaScript website; it does not need a build command.
- The relationship date and letter settings are saved in the current browser using local storage.
- Photos added from the page are stored in that browser only; they are not uploaded to a shared server and will not automatically appear on another person's device.
- The repository and published website are public. Do not put private information or intimate photos in the repository.
- The Netlify badge will not be present because this package contains the website itself, not Netlify's injected badge.
